
package com.example.accentapp;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Map;

public class GameActivity extends AppCompatActivity {
    private TextView wordTextView;
    private LinearLayout buttonsLayout;
    private Map<String, Integer> dictionary;
    private int correctIndex;
    private LinearLayout.LayoutParams params;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); // Ширина равна весу
        setContentView(R.layout.activity_game);

        wordTextView = findViewById(R.id.wordTextView);
        buttonsLayout = findViewById(R.id.buttonsLayout);

        dictionary = DictionaryCreator.createDictionary();
        loadNewWord();
    }

    private void loadNewWord() {
        Object[] words = dictionary.keySet().toArray();
        String currentWord = (String) words[(int) (Math.random() * words.length)];
        correctIndex = dictionary.get(currentWord);
        wordTextView.setText(currentWord);
        buttonsLayout.removeAllViews();
        for (int i = 0; i < currentWord.length(); i++) {
            char letter = currentWord.charAt(i);
            if (!isVowel(letter)) {
                continue;
            }

            Button button = new Button(this);
            button.setText(String.valueOf(letter));
            button.setLayoutParams(params);
            int index = i;
            button.setOnClickListener(v -> checkAnswer(index));
            buttonsLayout.addView(button);
        }
    }

    private static boolean isVowel(char letter) {
        letter = Character.toLowerCase(letter);
        return "аеёиоуыэюя".indexOf(letter) != -1;
    }

    private void checkAnswer(int selectedIndex) {
        if (selectedIndex == correctIndex) {
            Toast.makeText(this, "Правильно!", Toast.LENGTH_SHORT).show();
            loadNewWord();
        } else {
            Toast.makeText(this, "Неправильно. Попробуйте ещё раз.",
                    Toast.LENGTH_SHORT).show();
        }
    }
}
